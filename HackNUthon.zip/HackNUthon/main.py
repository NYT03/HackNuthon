import csv
from pymongo import MongoClient
import speech_recognition
import pyttsx3
import uuid
def ask_question(text,i):
    engine = pyttsx3.init()
    voices = engine.getProperty('voices')
    engine.setProperty('voice', voices[1].id)
    engine.setProperty("rate", 125)
    engine.say(text[i])
    engine.runAndWait()
# Example usage
def generate_unique_id(connection_uri, database_name, collection_name):
    uid=str(uuid.uuid4())
    print('GENERATING ID')
    if check_id_exists(connection_uri, database_name, collection_name,uid):
        return uid
    else:
        generate_unique_id(connection_uri, database_name, collection_name)
def check_id_exists(connection_uri, database_name, collection_name,uid):
    client = MongoClient(connection_uri)
    db = client[database_name]
    collection = db[collection_name]
    result = collection.find_one({"_id": uid})
    client.close()
    return result is None
def speech_to_text():
    recognizer = speech_recognition.Recognizer()
    try:
        with speech_recognition.Microphone() as mic:
            recognizer.adjust_for_ambient_noise(mic)
            print("starting...")
            recognizer.pause_threshold = 1
            audio = recognizer.listen(mic,phrase_time_limit=10,timeout=10)
            print("stopping...")
            answer = recognizer.recognize_google(audio)
            answer = answer.lower()
    except speech_recognition.UnknownValueError:
        print('someError occurred')
    return answer
  # Replace with the actual ID
def start_interview(connection_uri, database_name, collection_name,text,uid):
    print("hello")
    i=0
    t=1
    person=[]
    recognizer = speech_recognition.Recognizer()
    while t!=0:
        if(i==len(text)):
            break
        print("Say something: ")
        ask_question(text,i)
        i+=1
        try:
            with speech_recognition.Microphone() as mic:
                recognizer.adjust_for_ambient_noise(mic)
                print("starting...")
                recognizer.pause_threshold = 1
                audio = recognizer.listen(mic,phrase_time_limit=10,timeout=10)
                print("stopping...")
                answer = recognizer.recognize_google(audio)
                answer = answer.lower()
                print(answer)
                person.append(answer)
        except speech_recognition.UnknownValueError:
            print('someError occurred')
            continue
                # return render_template("index.html", message=text, response=chatbot_response)
    data={
        "_id":uid,
        "interviewer":text,
        "person":person,
    }
    store_data(connection_uri, database_name, collection_name, data)

def store_data(connection_uri, database_name, collection_name, data):
    from pymongo import MongoClient
    client = MongoClient(connection_uri)
    db = client[database_name]
    collection = db[collection_name]
    result = collection.insert_one(data)
    print(f"Document inserted with ID: {result.inserted_id}")
    client.close()


def export_document_to_csv(connection_uri, database_name, collection_name, uid, output_filename="exported_data.csv"):
  # Connect to MongoDB
  client = MongoClient(connection_uri)
  # Get database and collection
  db = client[database_name]
  collection = db[collection_name]
  # Find the document by ID
  document = collection.find_one({"_id": uid})
  if document is None:
      raise ValueError(f"No document found with ID: {uid}")
  data_to_export = []  # List to store data rows
  for key, value in document.items():
      if key != "_id":
          data_to_export.append([key, value])
  client.close()
  print(f"Data for ID {uid} exported to {output_filename}")
  return data_to_export
  # Open CSV file for writing
#   with open(output_filename, "w", newline="") as csvfile:
#       writer = csv.writer(csvfile)
#       writer.writerows(data_to_export)
  # Close connection

questions=[
    "What is your Name?",
    "What are your hobbies?",
    "What are your strengths and weaknesses?",
    "What is your favorite food?",
    ]
def main():
    start_interview(connection_uri = "mongodb://localhost:27017",
    database_name = "mydatabase",
    collection_name = "mycollection",text=questions,uid=1)
    # export_document_to_csv(connection_uri = "mongodb://localhost:27017",
    # database_name = "mydatabase",
    # collection_name = "mycollection",uid=1)
if __name__ == '__main__':
    main()
