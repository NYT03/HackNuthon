from flask import Flask,Blueprint, render_template, request, jsonify
import openai
from pymongo import MongoClient
import main
site = Blueprint('Site', __name__, template_folder='templetes')
app = Flask(__name__)
connection_uri = "mongodb://localhost:27017"
database_name = "mydatabase"
collection_name = "mycollection"
# Set your OpenAI API key here
openai.api_key = 'YOUR_OPENAI_API_KEY'

@app.route('/')
def home():
    return render_template('home.html')


@app.route('/get_response', methods=['POST'])
def get_response():
    uid=main.generate_unique_id(connection_uri=connection_uri, database_name=database_name, collection_name=collection_name,)
    user_message=main.speech_to_text()

    response = generate_response(user_message)
    return jsonify({'message': response})





def generate_response(user_message):
    # Use OpenAI's GPT-3 model to generate a response
    prompt = f"You are conducting an interview for a job position. The candidate said: '{user_message}'"
    response = openai.Completion.create(
        engine="text-davinci-003",
        prompt=prompt,
        max_tokens=50
    )
    return response.choices[0].text.strip()



if __name__ == '__main__':
    app.run(debug=True)