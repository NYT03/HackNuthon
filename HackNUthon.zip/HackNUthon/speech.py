import pyttsx3
import speech_recognition
import keyboard

t=1
recognizer = speech_recognition.Recognizer()

def stop_listening(event):
    if event.name == 'esc':
        print("Stopping the code...")
        t=0
        raise KeyboardInterrupt

keyboard.on_press(stop_listening)
while t!=0:
    print("Say something: ")
    try:
        with speech_recognition.Microphone() as mic:
            recognizer.adjust_for_ambient_noise(mic)
            print("starting...")
            audio = recognizer.listen(mic, timeout=1.5)
            print("stopping...")
            text = recognizer.recognize_google(audio)
            text = text.lower()

            print(f"Recognized {text}")

    except speech_recognition.UnknownValueError:
        continue
    except KeyboardInterrupt:
        t=0
    except speech_recognition.exceptions.WaitTimeoutError:
        print("Listening timed out. Please try again.")
keyboard.unhook_all()