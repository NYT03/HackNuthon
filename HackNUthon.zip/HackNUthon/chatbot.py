import speech_recognition as sr
import openai
import pyttsx3

# Replace with your OpenAI API key
openai.api_key = "sk-proj-OHsSMLtNMvR0eLSVHpdZT3BlbkFJj6r8yHxkKBAS3WF6xrDD"

# Initialize text-to-speech engine
engine = pyttsx3.init()

def speak(text):
  """Speaks the given text using the text-to-speech engine."""
  engine.say(text)
  engine.runAndWait()

def listen():
  """Listens for user input using the microphone and returns the recognized text."""
  r = sr.Recognizer()
  with sr.Microphone() as source:
    print("Listening...")
    r.non_speaking_duration = 0.5
    r.adjust_for_ambient_noise(source,duration=5)
    audio = r.listen(source)
  try:
    text = r.recognize_google(audio)
    print("You said: " + text)
    return text.lower()  # Convert to lowercase for case-insensitive matching
  except sr.UnknownValueError:
    print("Sorry, could not understand audio")
    return None
  except sr.RequestError as e:
    print("Could not request results from Google Speech Recognition service; {0}".format(e))
    return None

def interview():
  """Conducts a job interview by asking questions and generating responses."""
  questions = [
      "Tell me about your experience in the field.",
      "What are your strengths and weaknesses?",
      "Why are you interested in this position?",
      "Do you have any questions for me?"
  ]
  candidate_answers = {}

  for question in questions:
    voices = engine.getProperty('voices')
    engine.setProperty('voice', voices[1].id)
    speak(question)
    answer = listen()
    if answer is None:
      continue

    # Send the answer to OpenAI API for analysis (optional)
    response = openai.Completion.create(
        engine="text-davinci-003",  # Adjust as needed
        prompt=f"Analyze the answer '{answer}' for the question '{question}'.",
        max_tokens=256,  # Limit response length for analysis
        n=1,
        stop=None,
        temperature=0.7  # Control analysis style (optional)
    )
    analysis_text = response.choices[0].text.strip()
    print(f"Analysis: {analysis_text}")  # Optional: Display analysis for review

    candidate_answers[question] = answer

  # Summarize the interview and ask for final thoughts
  speak("Thank you for your answers. Here's a summary of your experience...")
  # Summarize candidate_answers here (e.g., using natural language processing)
  speak("Do you have any final thoughts you'd like to share?")
  listen()  # Listen for final thoughts (not processed by OpenAI here)

if __name__ == "__main__":
  print("Interview Bot is ready...")
  interview()
