from flask import Flask,Blueprint, render_template, request, jsonify
from pymongo import MongoClient
import main
site = Blueprint('Site', __name__, template_folder='templetes')
# Replace with your MongoDB connection URI, database, and collection names
connection_uri = "mongodb://localhost:27017"
database_name = "mydatabase"
collection_name = "mycollection"

app = Flask(__name__)
app.register_blueprint(site, url_prefix='/')
@app.route("/", methods=["GET", "POST"])
def index():
    uid=main.generate_unique_id(connection_uri=connection_uri, database_name=database_name, collection_name=collection_name,)
    if request.method == "POST":
        button_id = request.form.get("id")
        print(button_id)
        if button_id == 'start_interview' :
            print(uid)
            main.start_interview(connection_uri=connection_uri, database_name=database_name, collection_name=collection_name, text=main.questions,uid=uid)
        elif button_id == "retrieve_button":
            data_id = request.form.get('data_to_retrieve')  # Retrieve data ID from form
            retrieved_data = main.export_document_to_csv(connection_uri=connection_uri, database_name=database_name, collection_name=collection_name, uid=int(data_id))
            if retrieved_data:
                response = f"Data retrieved successfully: {retrieved_data}"
            else:
                response = "No data found with the provided ID."
        else:
            message = "Invalid button click."
        return jsonify({"message": response})
    else:
        return render_template("index.html")

if __name__ == "__main__":
    app.run(debug=True)
